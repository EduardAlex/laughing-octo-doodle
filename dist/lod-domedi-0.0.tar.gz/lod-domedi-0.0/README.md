# laughing-octo-doodle
i just pressed random on github's suggestions for a repo name

use 

`import lod`

`lod.laugh()`
