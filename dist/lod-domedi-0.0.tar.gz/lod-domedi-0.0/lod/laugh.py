def laugh(num=0):
	try:
		print(int(num)*"ha")
	except:
		print(":(")